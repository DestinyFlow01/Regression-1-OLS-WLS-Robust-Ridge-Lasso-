MatrixXcf v = MatrixXcf::Random(2, 3);
cout << v << endl << endl;
cout << v.cwiseArg() << endl;